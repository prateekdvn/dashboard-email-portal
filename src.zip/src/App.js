
import './App.css';
import Header from './components/Header';
import Nav from './components/Nav2'

function App() {
  return (
    <div className="App">
     
      <Header />
      <div style={{ width:'100%'}} >
      <div className=' Adiv1'>Welcome Remy sharp</div>
      <Nav />
     

     

      </div>
    </div>
  );
}

export default App;

import React,{useState} from 'react'




const DataTable=  ( {formData} ) =>{
    const [currentPage, setCurrentPage]=useState(1);
    const entriesperPage = 6;

    const startIndex = (currentPage -1)*entriesperPage;
    const endIndex = startIndex +entriesperPage;


    const currentData = formData.slice(startIndex,endIndex);
    console.log("currentData",currentData);
    currentData.map(item=>{
        console.log("item",item.data.dash1)
    })

    const handlePageChange = (newPage) =>{
        setCurrentPage(newPage);
    };

    return(
           <div style={{color:'#FFF',backgroundColor:'rgba(255, 255, 255, 0.00)'}}>
        <table className="table-bordered table-hover table-light" style={{fontSize:'15px',color:'white',width:'100%',height:'100%'}}>

                     <thead className='' style={{color:'white'}}>
                      <tr style={{color:'white',backgroundColor:'#171C8F'}}>

                        <th style={{padding:'20px',textAlign:'start'}}>Email</th>
                        <th style={{padding:'20px',textAlign:'start'}}>srnumber</th>
                        <th style={{padding:'20px',textAlign:'start'}}>iserve</th>
                        <th style={{padding:'20px',textAlign:'start'}}>dashboard1</th>
                        <th style={{padding:'20px',textAlign:'start'}}>dashboard2</th>
                        <th style={{padding:'20px',textAlign:'start'}}>dashboard3</th>
                        <th style={{padding:'20px',textAlign:'start'}}>dashboard4</th>
                      </tr>
                     </thead>

                     <tbody style={{color:'white'}}>
                            {currentData.map(item => (
                                <tr key={item?.data.srnumber}>
                                    <td style={{backgroundColor:'rgba(255, 255, 255, 0.10)',padding:'20px'}}>{item?.data.email}</td>
                                    <td>{item?.data.srnumber}</td>
                                    <td>{item?.data.iserve}</td>
                                    <td>{item.data.dash1}</td>
                                    <td>{item.data.dash2}</td>
                                    <td>{item.data.dash3}</td>
                                    <td>{item.data.dash4}</td>


                                </tr>
                           ) )}

                    <tr><td colSpan={7} style={{padding:'17px'}}> 
        <div className='' style={{display:'flex', justifyContent:'space-between'}}>
            <button onClick={()=> handlePageChange(currentPage-1)}
                 disabled={currentPage === 1}>
                previous
            </button>
            <span> page {currentPage}</span>
            <button   onClick={()=> handlePageChange(currentPage+1)}
                   disabled = {endIndex>=formData.length}>
                Next
            </button>

        </div></td></tr> 
        </tbody>
        </table>
        
        
        </div>
    )


}
export default DataTable;
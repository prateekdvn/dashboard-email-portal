import React from "react";



export default function EmailRegistration2({formData}){

       console.log(formData);

return<>



</>

}